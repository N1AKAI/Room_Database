package ma.n1akai.roomdatabase.listeners;

import android.view.View;

import ma.n1akai.roomdatabase.data.Person;

public interface OnPersonLongClickListener {
    void onLongClick(View view, Person person);
}
