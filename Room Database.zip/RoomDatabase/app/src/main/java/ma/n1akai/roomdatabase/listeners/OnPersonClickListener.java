package ma.n1akai.roomdatabase.listeners;

import android.view.View;

import ma.n1akai.roomdatabase.data.Person;

public interface OnPersonClickListener {
    void onClick(View view, Person person);
}
